﻿using System.Windows.Controls;

namespace TcpUdpTool.View
{
    /// <summary>
    /// Interaction logic for UdpMulticastView.xaml
    /// </summary>
    public partial class UdpAsmView : UserControl
    {
        public UdpAsmView()
        {
            InitializeComponent();
        }
    }
}
