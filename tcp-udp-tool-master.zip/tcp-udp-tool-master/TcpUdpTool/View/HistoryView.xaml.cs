﻿using System.Windows.Controls;

namespace TcpUdpTool.View
{
    /// <summary>
    /// Interaction logic for TcpClientView.xaml
    /// </summary>
    public partial class HistoryView : UserControl
    {
        public HistoryView()
        {
            InitializeComponent();
        }
    }
}
