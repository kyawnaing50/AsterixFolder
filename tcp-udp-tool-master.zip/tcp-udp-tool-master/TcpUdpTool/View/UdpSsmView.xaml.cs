﻿using System.Windows.Controls;

namespace TcpUdpTool.View
{
    /// <summary>
    /// Interaction logic for UdpMulticastView.xaml
    /// </summary>
    public partial class UdpSsmView : UserControl
    {
        public UdpSsmView()
        {
            InitializeComponent();
        }
    }
}
