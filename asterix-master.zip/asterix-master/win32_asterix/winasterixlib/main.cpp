#include "..\..\lib\libasterix\src\libasterix.h"
int main()
{
	
	return 0;
}