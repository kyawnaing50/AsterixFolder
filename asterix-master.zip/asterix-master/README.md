# asterix
Asterix project is freeware crossplatform astronomical calculation library

Libasterix writen on c/c++ for MS WIN32 and UNIX like 32 and 64 bit operating 
system support.
