﻿namespace WindowTextExtractor
{
    static class NativeConstants
    {
        public const int WM_LBUTTONUP = 0x0202;
        public const int WM_MOUSEMOVE = 0x0200;
        public const int WM_COPYDATA = 0x004A;
        public const int STD_OUTPUT_HANDLE = -11;
    }
}
