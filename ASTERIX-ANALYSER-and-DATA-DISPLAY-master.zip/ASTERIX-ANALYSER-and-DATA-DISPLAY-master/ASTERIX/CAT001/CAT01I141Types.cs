﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    class CAT01I141Types
    {

        public class CAT01141ElapsedTimeSinceMidnight
        {
            public double ElapsedTimeSinceMidnight;
        }
    }
}
