﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    class CAT01I200Types
    {
        public class CalculatedGSPandHDG_Type
        {
            public bool Is_Valid = false;
            public double GSPD = 0.0;
            public double HDG = 0.0;
        }
    }
}
