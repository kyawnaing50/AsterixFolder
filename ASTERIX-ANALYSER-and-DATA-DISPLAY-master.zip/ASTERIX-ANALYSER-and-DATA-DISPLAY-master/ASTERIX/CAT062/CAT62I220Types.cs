﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    class CAT62I220Types
    {
        // WORD 0 
        public class CalculatedRateOfClimbDescent
        {
           // (LSB) = 6.25 feet/minute
            public double Value = 0.0;
            public bool Is_Valid = false;
        }
    }
}
