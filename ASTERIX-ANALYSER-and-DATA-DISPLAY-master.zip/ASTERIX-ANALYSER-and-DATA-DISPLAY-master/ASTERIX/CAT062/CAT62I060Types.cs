﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    class CAT62I060Types
    {
        public class CAT62060Mode3UserData
        {
            public bool Mode_3A_Has_Changed = false;
            public string Mode3A_Code = "Unknown";
        }
    }
}
