﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    class CAT48I240Types
    {
        public class CAT48I240ACID_Data
        {
            public string ACID = "------"; 
        }
    }
}
