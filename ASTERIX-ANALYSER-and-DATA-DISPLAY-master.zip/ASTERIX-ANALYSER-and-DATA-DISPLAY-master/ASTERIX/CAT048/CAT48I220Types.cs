﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    class CAT48I220Types
    {
        public class CAT48AC_Address_Type
        {
            public string AC_ADDRESS_String = "------";
            public bool Is_Valid = false;
        }
    }
}
