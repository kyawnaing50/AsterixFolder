﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    class CAT48I170Types
    {

        public static int Word1_FX_Index = Bit_Ops.Bit0;
    }
}
