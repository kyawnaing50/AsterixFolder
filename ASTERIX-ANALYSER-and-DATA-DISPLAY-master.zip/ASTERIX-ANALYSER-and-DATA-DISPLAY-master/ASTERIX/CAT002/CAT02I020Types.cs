﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    // Sector Number
    class CAT02I020Types
    {
        // Just a double no need to define a new type
    }
}
