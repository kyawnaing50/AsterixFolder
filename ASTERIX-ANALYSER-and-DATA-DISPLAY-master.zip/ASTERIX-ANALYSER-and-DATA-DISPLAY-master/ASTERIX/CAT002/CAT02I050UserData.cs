﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    class CAT02I050UserData
    {
        public static void DecodeCAT02I050(byte[] Data)
        {


        }

    }
}
