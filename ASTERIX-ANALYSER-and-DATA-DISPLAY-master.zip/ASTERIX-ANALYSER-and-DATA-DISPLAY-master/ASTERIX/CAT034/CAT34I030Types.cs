﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsterixDisplayAnalyser
{
    class CAT34I030Types
    {

        public class CAT34I030_Time_Of_The_Day_User_Type
        {
            public double Time_Of_The_Day_In_Sec_Since_Midnight_UTC;
            public TimeSpan TimeOfDay = new TimeSpan();
        }
        
    }
}
