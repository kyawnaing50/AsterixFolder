﻿---------------------------------------------------------------------------------------
--											IMPORTANT !!!							---
		Please read the following before running the application for the first time

---------------------------------------------------------------------------------------


Please see DOCUMENTATION\User Manual.docx that is included as part of the project in Visual Studio.
For all specific questions please do not hesitate to contact me at akapetanovic@gmail.com

Make sure that machine where software is running (WIN OS) localisation is set to English U.S.
The software uses .NET libraries (ie. double.Parse) that depend on localisation. In the case
it is not set correctly the software is not able to correctly parse configuration files located
in the C:\ASTERIX\ADAPTATION directory.