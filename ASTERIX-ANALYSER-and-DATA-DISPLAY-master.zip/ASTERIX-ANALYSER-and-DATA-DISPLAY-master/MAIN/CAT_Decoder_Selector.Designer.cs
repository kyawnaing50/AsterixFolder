﻿namespace AsterixDisplayAnalyser
{
    partial class CAT_Decoder_Selector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBox002 = new System.Windows.Forms.CheckBox();
            this.checkBox008 = new System.Windows.Forms.CheckBox();
            this.checkBox034 = new System.Windows.Forms.CheckBox();
            this.checkBox048 = new System.Windows.Forms.CheckBox();
            this.checkBox062 = new System.Windows.Forms.CheckBox();
            this.checkBox063 = new System.Windows.Forms.CheckBox();
            this.checkBox065 = new System.Windows.Forms.CheckBox();
            this.checkBox244 = new System.Windows.Forms.CheckBox();
            this.checkBox001 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // checkBox002
            // 
            this.checkBox002.AutoSize = true;
            this.checkBox002.Location = new System.Drawing.Point(12, 30);
            this.checkBox002.Name = "checkBox002";
            this.checkBox002.Size = new System.Drawing.Size(68, 17);
            this.checkBox002.TabIndex = 1;
            this.checkBox002.Text = "CAT 002";
            this.checkBox002.UseVisualStyleBackColor = true;
            this.checkBox002.CheckedChanged += new System.EventHandler(this.checkBox002_CheckedChanged);
            // 
            // checkBox008
            // 
            this.checkBox008.AutoSize = true;
            this.checkBox008.Enabled = false;
            this.checkBox008.Location = new System.Drawing.Point(12, 48);
            this.checkBox008.Name = "checkBox008";
            this.checkBox008.Size = new System.Drawing.Size(68, 17);
            this.checkBox008.TabIndex = 2;
            this.checkBox008.Text = "CAT 008";
            this.checkBox008.UseVisualStyleBackColor = true;
            this.checkBox008.CheckedChanged += new System.EventHandler(this.checkBox008_CheckedChanged);
            // 
            // checkBox034
            // 
            this.checkBox034.AutoSize = true;
            this.checkBox034.Location = new System.Drawing.Point(12, 66);
            this.checkBox034.Name = "checkBox034";
            this.checkBox034.Size = new System.Drawing.Size(68, 17);
            this.checkBox034.TabIndex = 3;
            this.checkBox034.Text = "CAT 034";
            this.checkBox034.UseVisualStyleBackColor = true;
            this.checkBox034.CheckedChanged += new System.EventHandler(this.checkBox034_CheckedChanged);
            // 
            // checkBox048
            // 
            this.checkBox048.AutoSize = true;
            this.checkBox048.Location = new System.Drawing.Point(12, 84);
            this.checkBox048.Name = "checkBox048";
            this.checkBox048.Size = new System.Drawing.Size(68, 17);
            this.checkBox048.TabIndex = 4;
            this.checkBox048.Text = "CAT 048";
            this.checkBox048.UseVisualStyleBackColor = true;
            this.checkBox048.CheckedChanged += new System.EventHandler(this.checkBox048_CheckedChanged);
            // 
            // checkBox062
            // 
            this.checkBox062.AutoSize = true;
            this.checkBox062.Location = new System.Drawing.Point(12, 102);
            this.checkBox062.Name = "checkBox062";
            this.checkBox062.Size = new System.Drawing.Size(68, 17);
            this.checkBox062.TabIndex = 5;
            this.checkBox062.Text = "CAT 062";
            this.checkBox062.UseVisualStyleBackColor = true;
            this.checkBox062.CheckedChanged += new System.EventHandler(this.checkBox062_CheckedChanged);
            // 
            // checkBox063
            // 
            this.checkBox063.AutoSize = true;
            this.checkBox063.Enabled = false;
            this.checkBox063.Location = new System.Drawing.Point(12, 120);
            this.checkBox063.Name = "checkBox063";
            this.checkBox063.Size = new System.Drawing.Size(68, 17);
            this.checkBox063.TabIndex = 6;
            this.checkBox063.Text = "CAT 063";
            this.checkBox063.UseVisualStyleBackColor = true;
            this.checkBox063.CheckedChanged += new System.EventHandler(this.checkBox063_CheckedChanged);
            // 
            // checkBox065
            // 
            this.checkBox065.AutoSize = true;
            this.checkBox065.Enabled = false;
            this.checkBox065.Location = new System.Drawing.Point(12, 138);
            this.checkBox065.Name = "checkBox065";
            this.checkBox065.Size = new System.Drawing.Size(68, 17);
            this.checkBox065.TabIndex = 7;
            this.checkBox065.Text = "CAT 065";
            this.checkBox065.UseVisualStyleBackColor = true;
            this.checkBox065.CheckedChanged += new System.EventHandler(this.checkBox065_CheckedChanged);
            // 
            // checkBox244
            // 
            this.checkBox244.AutoSize = true;
            this.checkBox244.Enabled = false;
            this.checkBox244.Location = new System.Drawing.Point(12, 156);
            this.checkBox244.Name = "checkBox244";
            this.checkBox244.Size = new System.Drawing.Size(68, 17);
            this.checkBox244.TabIndex = 8;
            this.checkBox244.Text = "CAT 244";
            this.checkBox244.UseVisualStyleBackColor = true;
            this.checkBox244.CheckedChanged += new System.EventHandler(this.checkBox244_CheckedChanged);
            // 
            // checkBox001
            // 
            this.checkBox001.AutoSize = true;
            this.checkBox001.Location = new System.Drawing.Point(12, 12);
            this.checkBox001.Name = "checkBox001";
            this.checkBox001.Size = new System.Drawing.Size(68, 17);
            this.checkBox001.TabIndex = 9;
            this.checkBox001.Text = "CAT 001";
            this.checkBox001.UseVisualStyleBackColor = true;
            this.checkBox001.CheckedChanged += new System.EventHandler(this.checkBox001_CheckedChanged);
            // 
            // CAT_Decoder_Selector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(200, 179);
            this.Controls.Add(this.checkBox001);
            this.Controls.Add(this.checkBox244);
            this.Controls.Add(this.checkBox065);
            this.Controls.Add(this.checkBox063);
            this.Controls.Add(this.checkBox062);
            this.Controls.Add(this.checkBox048);
            this.Controls.Add(this.checkBox034);
            this.Controls.Add(this.checkBox008);
            this.Controls.Add(this.checkBox002);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CAT_Decoder_Selector";
            this.Text = "Category decoder selector";
            this.Load += new System.EventHandler(this.CAT_Decoder_Selector_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox002;
        private System.Windows.Forms.CheckBox checkBox008;
        private System.Windows.Forms.CheckBox checkBox034;
        private System.Windows.Forms.CheckBox checkBox048;
        private System.Windows.Forms.CheckBox checkBox062;
        private System.Windows.Forms.CheckBox checkBox063;
        private System.Windows.Forms.CheckBox checkBox065;
        private System.Windows.Forms.CheckBox checkBox244;
        private System.Windows.Forms.CheckBox checkBox001;
    }
}