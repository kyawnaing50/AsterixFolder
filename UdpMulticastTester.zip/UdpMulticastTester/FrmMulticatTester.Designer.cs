﻿namespace UdpMulticastTester
{
    partial class FrmMulticatTester
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label portLabel;
            System.Windows.Forms.Label portLabel1;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label addressLabel1;
            System.Windows.Forms.Label addressLabel2;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            this.m_textBoxReceivePort = new System.Windows.Forms.TextBox();
            this.m_textBoxSendMulticastPort = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.m_comboBoxReceiveAddress = new System.Windows.Forms.ComboBox();
            this.m_textBoxReceiveMulticastAddress = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.m_textBoxSendPort = new System.Windows.Forms.TextBox();
            this.m_comboBoxSendAddress = new System.Windows.Forms.ComboBox();
            this.m_textBoxSendMulticastAddress = new System.Windows.Forms.TextBox();
            this.m_textBoxMessage = new System.Windows.Forms.TextBox();
            this.m_btnSend = new System.Windows.Forms.Button();
            this.m_listViewMessages = new System.Windows.Forms.ListView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.m_btnDisconnect = new System.Windows.Forms.Button();
            this.m_btnConnect = new System.Windows.Forms.Button();
            this.m_btnRevert = new System.Windows.Forms.Button();
            portLabel = new System.Windows.Forms.Label();
            portLabel1 = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            addressLabel1 = new System.Windows.Forms.Label();
            addressLabel2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // portLabel
            // 
            portLabel.AutoSize = true;
            portLabel.Location = new System.Drawing.Point(14, 34);
            portLabel.Name = "portLabel";
            portLabel.Size = new System.Drawing.Size(29, 13);
            portLabel.TabIndex = 3;
            portLabel.Text = "Port:";
            // 
            // portLabel1
            // 
            portLabel1.AutoSize = true;
            portLabel1.Location = new System.Drawing.Point(13, 56);
            portLabel1.Name = "portLabel1";
            portLabel1.Size = new System.Drawing.Size(29, 13);
            portLabel1.TabIndex = 7;
            portLabel1.Text = "Port:";
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.Location = new System.Drawing.Point(14, 60);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(93, 13);
            addressLabel.TabIndex = 4;
            addressLabel.Text = "Multicast Address:";
            // 
            // addressLabel1
            // 
            addressLabel1.AutoSize = true;
            addressLabel1.Location = new System.Drawing.Point(14, 146);
            addressLabel1.Name = "addressLabel1";
            addressLabel1.Size = new System.Drawing.Size(116, 13);
            addressLabel1.TabIndex = 5;
            addressLabel1.Text = "Network Card Address:";
            // 
            // addressLabel2
            // 
            addressLabel2.AutoSize = true;
            addressLabel2.Location = new System.Drawing.Point(13, 29);
            addressLabel2.Name = "addressLabel2";
            addressLabel2.Size = new System.Drawing.Size(93, 13);
            addressLabel2.TabIndex = 8;
            addressLabel2.Text = "Multicast Address:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(11, 140);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(116, 13);
            label1.TabIndex = 10;
            label1.Text = "Network Card Address:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(11, 169);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(97, 13);
            label2.TabIndex = 12;
            label2.Text = "Network Card Port:";
            // 
            // m_textBoxReceivePort
            // 
            this.m_textBoxReceivePort.Location = new System.Drawing.Point(139, 27);
            this.m_textBoxReceivePort.Name = "m_textBoxReceivePort";
            this.m_textBoxReceivePort.Size = new System.Drawing.Size(100, 20);
            this.m_textBoxReceivePort.TabIndex = 4;
            this.m_textBoxReceivePort.Text = "1340";
            // 
            // m_textBoxSendMulticastPort
            // 
            this.m_textBoxSendMulticastPort.Location = new System.Drawing.Point(139, 56);
            this.m_textBoxSendMulticastPort.Name = "m_textBoxSendMulticastPort";
            this.m_textBoxSendMulticastPort.Size = new System.Drawing.Size(100, 20);
            this.m_textBoxSendMulticastPort.TabIndex = 8;
            this.m_textBoxSendMulticastPort.Text = "1339";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.m_comboBoxReceiveAddress);
            this.groupBox1.Controls.Add(addressLabel1);
            this.groupBox1.Controls.Add(addressLabel);
            this.groupBox1.Controls.Add(this.m_textBoxReceiveMulticastAddress);
            this.groupBox1.Controls.Add(this.m_textBoxReceivePort);
            this.groupBox1.Controls.Add(portLabel);
            this.groupBox1.Location = new System.Drawing.Point(12, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(246, 184);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Recieve";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label4.Location = new System.Drawing.Point(16, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 17);
            this.label4.TabIndex = 20;
            this.label4.Text = "for multiple network cards";
            // 
            // m_comboBoxReceiveAddress
            // 
            this.m_comboBoxReceiveAddress.FormattingEnabled = true;
            this.m_comboBoxReceiveAddress.Location = new System.Drawing.Point(134, 145);
            this.m_comboBoxReceiveAddress.Name = "m_comboBoxReceiveAddress";
            this.m_comboBoxReceiveAddress.Size = new System.Drawing.Size(100, 21);
            this.m_comboBoxReceiveAddress.TabIndex = 12;
            // 
            // m_textBoxReceiveMulticastAddress
            // 
            this.m_textBoxReceiveMulticastAddress.Location = new System.Drawing.Point(139, 56);
            this.m_textBoxReceiveMulticastAddress.Name = "m_textBoxReceiveMulticastAddress";
            this.m_textBoxReceiveMulticastAddress.Size = new System.Drawing.Size(100, 20);
            this.m_textBoxReceiveMulticastAddress.TabIndex = 5;
            this.m_textBoxReceiveMulticastAddress.Text = "224.0.0.12";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(label2);
            this.groupBox2.Controls.Add(this.m_textBoxSendPort);
            this.groupBox2.Controls.Add(this.m_comboBoxSendAddress);
            this.groupBox2.Controls.Add(label1);
            this.groupBox2.Controls.Add(addressLabel2);
            this.groupBox2.Controls.Add(this.m_textBoxSendMulticastAddress);
            this.groupBox2.Controls.Add(portLabel1);
            this.groupBox2.Controls.Add(this.m_textBoxSendMulticastPort);
            this.groupBox2.Location = new System.Drawing.Point(12, 326);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(245, 193);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Send";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label3.Location = new System.Drawing.Point(14, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(169, 17);
            this.label3.TabIndex = 14;
            this.label3.Text = "for multiple network cards";
            // 
            // m_textBoxSendPort
            // 
            this.m_textBoxSendPort.Location = new System.Drawing.Point(137, 169);
            this.m_textBoxSendPort.Name = "m_textBoxSendPort";
            this.m_textBoxSendPort.Size = new System.Drawing.Size(100, 20);
            this.m_textBoxSendPort.TabIndex = 13;
            this.m_textBoxSendPort.Text = "0";
            // 
            // m_comboBoxSendAddress
            // 
            this.m_comboBoxSendAddress.FormattingEnabled = true;
            this.m_comboBoxSendAddress.Location = new System.Drawing.Point(137, 142);
            this.m_comboBoxSendAddress.Name = "m_comboBoxSendAddress";
            this.m_comboBoxSendAddress.Size = new System.Drawing.Size(100, 21);
            this.m_comboBoxSendAddress.TabIndex = 11;
            // 
            // m_textBoxSendMulticastAddress
            // 
            this.m_textBoxSendMulticastAddress.Location = new System.Drawing.Point(139, 29);
            this.m_textBoxSendMulticastAddress.Name = "m_textBoxSendMulticastAddress";
            this.m_textBoxSendMulticastAddress.Size = new System.Drawing.Size(100, 20);
            this.m_textBoxSendMulticastAddress.TabIndex = 9;
            this.m_textBoxSendMulticastAddress.Text = "224.0.0.11";
            // 
            // m_textBoxMessage
            // 
            this.m_textBoxMessage.Location = new System.Drawing.Point(93, 74);
            this.m_textBoxMessage.Name = "m_textBoxMessage";
            this.m_textBoxMessage.Size = new System.Drawing.Size(460, 20);
            this.m_textBoxMessage.TabIndex = 11;
            this.m_textBoxMessage.Text = "aviad";
            // 
            // m_btnSend
            // 
            this.m_btnSend.Enabled = false;
            this.m_btnSend.Location = new System.Drawing.Point(12, 71);
            this.m_btnSend.Name = "m_btnSend";
            this.m_btnSend.Size = new System.Drawing.Size(75, 23);
            this.m_btnSend.TabIndex = 12;
            this.m_btnSend.Text = "&Send";
            this.m_btnSend.UseVisualStyleBackColor = true;
            this.m_btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // m_listViewMessages
            // 
            this.m_listViewMessages.Location = new System.Drawing.Point(272, 117);
            this.m_listViewMessages.Name = "m_listViewMessages";
            this.m_listViewMessages.Size = new System.Drawing.Size(281, 383);
            this.m_listViewMessages.TabIndex = 13;
            this.m_listViewMessages.UseCompatibleStateImageBehavior = false;
            this.m_listViewMessages.View = System.Windows.Forms.View.List;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.m_btnDisconnect);
            this.groupBox3.Controls.Add(this.m_btnConnect);
            this.groupBox3.Location = new System.Drawing.Point(13, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(542, 48);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            // 
            // m_btnDisconnect
            // 
            this.m_btnDisconnect.Enabled = false;
            this.m_btnDisconnect.Location = new System.Drawing.Point(90, 16);
            this.m_btnDisconnect.Name = "m_btnDisconnect";
            this.m_btnDisconnect.Size = new System.Drawing.Size(75, 23);
            this.m_btnDisconnect.TabIndex = 1;
            this.m_btnDisconnect.Text = "Disconnect";
            this.m_btnDisconnect.UseVisualStyleBackColor = true;
            this.m_btnDisconnect.Click += new System.EventHandler(this.m_btnDisconnect_Click);
            // 
            // m_btnConnect
            // 
            this.m_btnConnect.Location = new System.Drawing.Point(9, 16);
            this.m_btnConnect.Name = "m_btnConnect";
            this.m_btnConnect.Size = new System.Drawing.Size(75, 23);
            this.m_btnConnect.TabIndex = 0;
            this.m_btnConnect.Text = "Connect";
            this.m_btnConnect.UseVisualStyleBackColor = true;
            this.m_btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // m_btnRevert
            // 
            this.m_btnRevert.Location = new System.Drawing.Point(39, 297);
            this.m_btnRevert.Name = "m_btnRevert";
            this.m_btnRevert.Size = new System.Drawing.Size(94, 23);
            this.m_btnRevert.TabIndex = 15;
            this.m_btnRevert.Text = "Revert";
            this.m_btnRevert.UseVisualStyleBackColor = true;
            this.m_btnRevert.Click += new System.EventHandler(this.m_btnRevert_Click);
            // 
            // FrmMulticatTester
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 531);
            this.Controls.Add(this.m_btnRevert);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.m_listViewMessages);
            this.Controls.Add(this.m_btnSend);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.m_textBoxMessage);
            this.Name = "FrmMulticatTester";
            this.Text = "Multicast Tester";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox m_textBoxReceivePort;
        private System.Windows.Forms.TextBox m_textBoxSendMulticastPort;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox m_textBoxMessage;
        private System.Windows.Forms.Button m_btnSend;
        private System.Windows.Forms.ListView m_listViewMessages;
        private System.Windows.Forms.TextBox m_textBoxReceiveMulticastAddress;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button m_btnConnect;
        private System.Windows.Forms.Button m_btnDisconnect;
        private System.Windows.Forms.TextBox m_textBoxSendMulticastAddress;
        private System.Windows.Forms.Button m_btnRevert;
        private System.Windows.Forms.ComboBox m_comboBoxSendAddress;
        private System.Windows.Forms.ComboBox m_comboBoxReceiveAddress;
        private System.Windows.Forms.TextBox m_textBoxSendPort;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;


    }
}

