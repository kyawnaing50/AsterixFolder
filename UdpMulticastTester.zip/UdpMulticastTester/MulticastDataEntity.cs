﻿using System.Net;

namespace UdpMulticastTester
{
    class MulticastDataEntity
    {
        private readonly IPAddress m_SendMulticastAddress;
        private readonly int m_SendPort;
        private readonly int m_ReceivePort;
        private readonly IPAddress m_ReceiveMulticastAddress;

        private readonly IPAddress m_SendNetworkCardAddress = IPAddress.Any;
        private readonly int m_SendNetworkCardPort;
        private readonly IPAddress m_ReceiveNetworkCardAddress = IPAddress.Any;

        public MulticastDataEntity(IPAddress sendMulticastAddress, int sendPort, IPAddress receiveMulticastAddress, int receivePort)
        {
            m_SendMulticastAddress = sendMulticastAddress;
            m_SendPort = sendPort;
            m_ReceiveMulticastAddress = receiveMulticastAddress;
            m_ReceivePort = receivePort;
        }

        public MulticastDataEntity(IPAddress sendMulticastAddress, int sendPort, IPAddress receiveMulticastAddress, int receivePort,
            IPAddress sendExplicitSourceAddressm, int sendExplicitSourcePort, IPAddress receiveExplicitSourceAddress)
            : this(sendMulticastAddress, sendPort, receiveMulticastAddress, receivePort)
        {
            m_SendNetworkCardAddress = sendExplicitSourceAddressm;
            m_SendNetworkCardPort = sendExplicitSourcePort;
            m_ReceiveNetworkCardAddress = receiveExplicitSourceAddress;
        }

        public IPAddress SendMulticastAddress
        {
            get { return m_SendMulticastAddress; }
        }

        public int SendPort
        {
            get { return m_SendPort; }
        }

        public IPAddress ReceiveMulticastAddress
        {
            get { return m_ReceiveMulticastAddress; }
        }

        public int ReceivePort
        {
            get { return m_ReceivePort; }
        }

        public IPAddress SendNetworkCardAddress
        {
            get { return m_SendNetworkCardAddress; }
        }

        public int SendNetworkCardPort
        {
            get { return m_SendNetworkCardPort; }
        }

        public IPAddress ReceiveNetworkCardAddress
        {
            get { return m_ReceiveNetworkCardAddress; }
        }
    }
}
