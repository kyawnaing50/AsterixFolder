﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;

namespace UdpMulticastTester
{
    class TransportAgent
    {
        class StateObject
        {
            private readonly byte[] m_buffer;
            private Socket m_workSocket;

            internal StateObject(Socket workSocket, byte[] buffer)
            {
                m_workSocket = workSocket;
                m_buffer = buffer;
            }

            internal Socket WorkSocket
            {
                get { return m_workSocket; }
                set { m_workSocket = value; }
            }

            internal byte[] Buffer
            {
                get { return m_buffer; }
            }
        }

        static readonly IPEndPoint AnyAddress = new IPEndPoint(IPAddress.Any, 0);
        private readonly byte[] m_objectStateBuffer = new byte[8192];

        private readonly MulticastDataEntity m_dataEntity;

        private readonly Socket m_sendSocket;
        private readonly Socket m_receiveSocket;
        private  bool m_opened;

        public TransportAgent(MulticastDataEntity entity, EventHandler<BufferReceivedEventArgs> messageReceived): this(entity)
        {
            MessageReceived += messageReceived;
        }

        public TransportAgent(MulticastDataEntity entity)
        {
            m_dataEntity = entity;
            
            m_sendSocket = CreateUdpSocket();

            EndPoint sendEndPoint = new IPEndPoint(m_dataEntity.SendNetworkCardAddress, m_dataEntity.SendNetworkCardPort);
            m_sendSocket.Bind(sendEndPoint);

            m_receiveSocket = CreateUdpSocket();
            EndPoint receiveEndPoint = new IPEndPoint(m_dataEntity.ReceiveNetworkCardAddress, m_dataEntity.ReceivePort);
            m_receiveSocket.Bind(receiveEndPoint);
            JoinMulticast(m_receiveSocket);

            BeginReceive();

            m_opened = true;
        }

        public void Close()
        {
            if (!m_opened)
            {
                return;
            }

            DropMulticast(m_receiveSocket);
            m_receiveSocket.Close();
            m_sendSocket.Close();

            m_opened = false;
        }

        private static Socket CreateUdpSocket()
        {
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            return socket;

        }

        private void JoinMulticast(Socket socket)
        {
            MulticastOption multicastOption = GetMulticastOption();
            socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastTimeToLive, 64);
            socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, multicastOption);

        }

        private void DropMulticast(Socket socket)
        {
            MulticastOption multicastOption = GetMulticastOption();
            socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastTimeToLive, 64);
            socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.DropMembership, multicastOption);
        }

        private MulticastOption GetMulticastOption()
        {
            IPAddress ip = m_dataEntity.ReceiveMulticastAddress;  
            MulticastOption mo = new MulticastOption(ip);
            return mo;
        }

        public void Send(byte[] message)
        {
            StateObject stateObject = new StateObject(m_sendSocket, message);

            IPEndPoint endPoint = new IPEndPoint(m_dataEntity.SendMulticastAddress, m_dataEntity.SendPort);
            m_sendSocket.BeginSendTo(message, 0, message.Length, SocketFlags.None, endPoint, OnSend, stateObject);
            
        }

        private void OnSend(IAsyncResult ar)
        {
            int bytesCount = m_sendSocket.EndSendTo(ar);
            Trace.WriteLine(string.Format("Messages Sent, Bytes: {0}", bytesCount));
        }

        public event EventHandler<BufferReceivedEventArgs> MessageReceived = delegate { };

        private void BeginReceive()
        {
            Socket receiveSocket = m_receiveSocket;
            if (receiveSocket == null) return;
         
            EndPoint remoteEP = AnyAddress;

            StateObject stateObject = new StateObject(receiveSocket, m_objectStateBuffer);

            receiveSocket.BeginReceiveFrom(stateObject.Buffer, 0, stateObject.Buffer.Length, SocketFlags.None, ref remoteEP, OnReceive, stateObject);
        }

        private void OnReceive(IAsyncResult result)
        {
            EndPoint remoteEP = AnyAddress;
            try
            {
                int bufferSize = m_receiveSocket.EndReceiveFrom(result, ref remoteEP);

                StateObject stateObject = (StateObject)result.AsyncState;
                
                BufferReceivedEventArgs e = new BufferReceivedEventArgs(stateObject.Buffer, bufferSize);
                MessageReceived(this, e);
                
                BeginReceive();
            }
            catch
            {
                Trace.WriteLine("Disconnection");
            }

        }
    }

    public class BufferReceivedEventArgs : EventArgs
    {
        private readonly byte[] m_buffer;
        private readonly int m_length;
 
        public BufferReceivedEventArgs(byte[] buffer, int length)
        {
            m_buffer = buffer;
            m_length = length;
        }

        public byte[] Buffer
        {
            get { return m_buffer; }
        }

        public int Length
        {
            get { return m_length; }

        }
    }

}
