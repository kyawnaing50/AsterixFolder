﻿using System;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace UdpMulticastTester
{
    public partial class FrmMulticatTester : Form
    {
        private TransportAgent m_TransportAgent;
        public FrmMulticatTester()
        {
            InitializeComponent();

            string hostName = Dns.GetHostName();
            IPHostEntry hostEntry = Dns.GetHostEntry(hostName);

            IPAddress[] addressList = hostEntry.AddressList;

            foreach (IPAddress address in addressList)
            {
                m_comboBoxSendAddress.Items.Add(address.ToString());
                m_comboBoxReceiveAddress.Items.Add(address.ToString());
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_TransportAgent == null) return;

            m_TransportAgent.Close();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            MulticastDataEntity multicastDataEntity = ReadConfiguration();

            m_TransportAgent = new TransportAgent(multicastDataEntity, OnMessageReceived);

            m_btnConnect.Enabled = false;
            m_btnDisconnect.Enabled = true;
            m_btnRevert.Enabled = false;
            groupBox1.Enabled = false;
            groupBox2.Enabled = false;

            m_btnSend.Enabled = true;
           
        }

        private void m_btnDisconnect_Click(object sender, EventArgs e)
        {
            m_TransportAgent.Close();

            m_btnConnect.Enabled = true;
            m_btnDisconnect.Enabled = false;
            m_btnRevert.Enabled = true;
            groupBox1.Enabled = true;
            groupBox2.Enabled = true;

            m_btnSend.Enabled = false;
        }

        private MulticastDataEntity ReadConfiguration()
        {
            IPAddress receiveSourceAddress = IPAddress.Any;
            IPAddress sendExplicitSourceAddress = IPAddress.Any;
            int sendExplicitSourcePort = 0;

            if (!string.IsNullOrEmpty(m_comboBoxSendAddress.Text))
            {
                receiveSourceAddress = IPAddress.Parse(m_comboBoxSendAddress.Text);
            }
            if (!string.IsNullOrEmpty(m_comboBoxReceiveAddress.Text))
            {
                sendExplicitSourceAddress = IPAddress.Parse(m_comboBoxReceiveAddress.Text);
                sendExplicitSourcePort = int.Parse(m_textBoxSendPort.Text);
            }

            MulticastDataEntity multicastDataEntity = new MulticastDataEntity(
                IPAddress.Parse(m_textBoxSendMulticastAddress.Text), int.Parse(m_textBoxSendMulticastPort.Text),
                IPAddress.Parse(m_textBoxReceiveMulticastAddress.Text), int.Parse(m_textBoxReceivePort.Text),
                sendExplicitSourceAddress, sendExplicitSourcePort, receiveSourceAddress);


            return multicastDataEntity;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            ASCIIEncoding asciiEncoding = new ASCIIEncoding();
            byte[] bytes = asciiEncoding.GetBytes(m_textBoxMessage.Text);

            m_TransportAgent.Send(bytes);
        }

        private void OnMessageReceived(object sender, BufferReceivedEventArgs e)
        {
            if (InvokeRequired)
            {
                BeginInvoke((ThreadStart) delegate
                                              {
                                                  OnMessageReceived(sender, e);
                                              });
                return;
            }

            string message = Encoding.ASCII.GetString(e.Buffer);
            m_listViewMessages.Items.Add(message);
        }

        private void m_btnRevert_Click(object sender, EventArgs e)
        {
            MulticastDataEntity data = ReadConfiguration();
            m_textBoxReceiveMulticastAddress.Text = data.SendMulticastAddress.ToString();
            m_textBoxSendMulticastAddress.Text = data.ReceiveMulticastAddress.ToString();
            m_textBoxSendMulticastPort.Text = data.ReceivePort.ToString();
            m_textBoxReceivePort.Text = data.SendPort.ToString();

        }
    }
}
